#include<iostream>
using namespace std;

int main()
{
    char ch;
    ch = getchar();
    if(ch<='z' && ch>='a')
        cout<< char(ch - 'a' + 'A');
    else
        cout<<char(ch);
        
    char str[1000];
    gets(str);
    puts(str);
    return 0;

}