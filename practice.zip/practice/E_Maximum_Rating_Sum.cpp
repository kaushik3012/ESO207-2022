#include<iostream>
#define ll long long
using namespace std;

int main() 
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    ll N;
    cin>>N;
    ll A[N];
    for(ll i=0;i<N;i++)
        cin>>A[i];

    ll maxi=A[0],sum=A[0];

    for(ll j=1;j<N;j++)
    {
        if(sum<0)
            sum = A[j];
        else
            sum = A[j]+sum;
        
        if(maxi < sum)
            maxi=sum;
    }

    cout<<maxi<<endl;
    return 0;
}
