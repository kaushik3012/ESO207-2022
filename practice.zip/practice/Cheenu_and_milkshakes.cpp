#include<bits/stdc++.h>
#define ll long long
using namespace std;

#define LIM_N 1010
#define LIM_M 1010

ll matrix[LIM_N][LIM_M];
bool vis[LIM_N][LIM_M];
int dist[LIM_N][LIM_M];
queue<pair<int, int> > q;
ll querie_arr[LIM_N + LIM_M];

// Direction vectors
int dRow[] = { -1, 0, 1, 0 };
int dCol[] = { 0, 1, 0, -1 };
 
// Function to check if a cell
// is be visited or not
bool isValid(int i, int j, int N, int M)
{
    // If cell lies out of bounds
    if (i < 0 || j < 0 || i >= N || j >= M)
        return false;
 
    // If cell is already visited
    if (vis[i][j])
        return false;
 
    // Otherwise
    return true;
}
 
// Function to perform the BFS traversal
void BFS(int N, int M)
{
    // ll mini = 1e9+1;
    while (!q.empty()) 
    { 
        pair<int, int> cell = q.front();
        int x = cell.first;
        int y = cell.second;
 
        q.pop();
        
        // if(matrix[x][y]>0 && matrix[x][y]<mini)
        //     mini = matrix[x][y];

        // querie_arr[dist[x][y]] = mini;

        // Go to the adjacent cells
        for (int i = 0; i < 4; i++) 
        { 
            int adjx = x + dRow[i];
            int adjy = y + dCol[i];
 
            if (isValid(adjx, adjy, N, M)) 
            {
                q.push({ adjx, adjy });
                vis[adjx][adjy] = true;
                // if(matrix[adjx][adjy]>0 && matrix[adjx][adjy] < mini)
                //     mini = matrix[adjx][adjy];
                
                // if(adjx<1 && adjy<1)
                //     dist[adjx][adjy] = min(dist[adjx+1][adjy],dist[adjx][adjy+1]) +1;
                // else if(adjx<1 && adjy==M-1)
                //     dist[adjx][adjy] = min(dist[adjx][adjy-1],dist[adjx+1][adjy])  +1;
                // else if(adjx==N-1 && adjy<1)
                //     dist[adjx][adjy] = min(dist[adjx-1][adjy],dist[adjx][adjy+1])  +1;
                // else if(adjx==N-1 && adjy==M-1)
                //     dist[adjx][adjy] = min(dist[adjx-1][adjy], dist[adjx][adjy-1])  +1;
                // else if(adjx<1) 
                //     dist[adjx][adjy] = min(min(dist[adjx][adjy-1], dist[adjx][adjy+1]),dist[adjx+1][adjy])  +1;
                // else if(adjy<1)
                //     dist[adjx][adjy] = min(min(dist[adjx-1][adjy], dist[adjx][adjy+1]),dist[adjx+1][adjy])  +1;
                // else if(adjy==M-1)
                //     dist[adjx][adjy] = min(min(dist[adjx-1][adjy], dist[adjx][adjy-1]),dist[adjx+1][adjy])  +1;
                // else if(adjx==N-1)
                //     dist[adjx][adjy] = min(min(dist[adjx][adjy-1], dist[adjx-1][adjy]),dist[adjx][adjy+1])  +1;
                // else
                //     dist[adjx][adjy] = min( min(dist[adjx-1][adjy],dist[adjx][adjy-1]), min(dist[adjx+1][adjy],dist[adjx][adjy+1]) ) + 1;

                dist[adjx][adjy] = dist[x][y] + 1;

                // querie_arr[dist[adjx][adjy]] = mini;
                // cout<<dist[adjx][adjy]<<" ";
            }
        }
    }
}


int main()
{
    int m,n;
    cin>>n>>m;

    for(int i=0; i<n; i++)
    {
        for(int j=0; j<m; j++)
        {
            matrix[i][j] = 0;
        }
    }    

    int s;
    cin>>s;
    for(int i=0; i<s; i++)
    {
        int sx,sy;
        ll c;
        cin>>sx>>sy>>c;
        matrix[sx-1][sy-1] = c;
    }

    memset(vis, false, sizeof(vis));
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<m; j++)
        {
            dist[i][j] = (int)(1e5+1);
        }
    }    

    int k;
    cin>>k;
    for(int i=0; i<k; i++)
    {
        int startx,starty;
        cin>>startx>>starty;
        matrix[startx-1][starty-1] = -1;
        q.push({startx-1,starty-1});
        vis[startx-1][starty-1] = true;
        dist[startx-1][starty-1] = 0;
    }

    BFS(n,m);
    // cout<<endl;

    // for(int i=0; i<n; i++)
    // {
    //     for(int j=0; j<m; j++)
    //     {
    //         cout<<matrix[i][j]<<" ";
    //     }   
    //     cout<<endl;
    // }    

    // for(int i=0; i<n; i++)
    // {
    //     for(int j=0; j<m; j++)
    //     {
    //         cout<<dist[i][j]<<" ";
    //     }   
    //     cout<<endl;
    // }    
    for(int i=0;i<n+m;i++)
        querie_arr[i]=(ll)(1e9 +1);

    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            // cout<<dist[i][j]<<" ";
            if(matrix[i][j]>0){
                querie_arr[dist[i][j]]=min(querie_arr[dist[i][j]],matrix[i][j]);
            }
        }
    }
    
    ll mini=(ll)(1e9 +1);
    for(int i=0;i<n+m;i++)
    {
        mini= min(mini,querie_arr[i]);
        querie_arr[i]=mini;
    }

    for(int i=1; i<=m+n; i++)
    {
        if(querie_arr[i]==0)
            querie_arr[i] = querie_arr[i-1];
    }

    int q;
    cin>>q;
    while(q--)
    {
        int t;
        cin>>t;
        if(t>=n+m){
            if(querie_arr[n+m-1]!=(ll)(1e9 +1))
                cout<<querie_arr[n+m-1]<<" ";
            else
                cout<<"-1 ";
        }
        else if(t<=0 || querie_arr[t] == 1e9+1)
            cout<<-1<<" ";
        else
            cout<<querie_arr[t]<<" ";
    }
    cout<<endl;
    return 0;
}
