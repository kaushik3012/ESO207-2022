#include<iostream>
#include <vector>
#define ll long long

using namespace std;

//Class for storing cell of a matrix
class cell
{
    public:
    int x,y;
};

//Creating node for the queue
struct QNode
{
    cell c;
    QNode* next;
    QNode(cell new_c)
    {
        c.x = new_c.x;
        c.y = new_c.y;
        next = NULL;
    }
};
 
//Class for the Queue data structure
class Queue
{
    QNode *front, *rear;
    ll size;

    public:

    Queue()
    {
        front = rear = NULL;
        size=0;
    }

    //Function to push element into the rear of queue
    void push(cell c)
    {
 
        // Create a new LL node
        QNode* temp = new QNode(c);
 
        // If queue is empty, then new node is front and rear both
        if (rear == NULL)
        {
            front = rear = temp;
            size++;
            return;
        }
 
        // Add the new node at the end of queue and change rear
        rear->next = temp;
        rear = temp;
        size++;
    }
 
    // Function to remove the front from given queue
    int pop()
    {
        // If queue is empty, return NULL.
        if ((front == NULL) || (rear == NULL))
        {
            size=0;
            return -1;
        }
 
        // Store previous front and move front one node ahead
        QNode* temp = front;
        front = front->next;
 
        // If front becomes NULL, then change rear also as NULL
        if (front == NULL)
            rear = NULL;
 
        delete(temp);
        size--;
        return 1;
    }

    //Function to return front element of the queue
    cell retFront()
    {
        return (front->c);
    }

    //Function to check if the queue is empty or not
    bool empty()
    {
        return (front == NULL);
    }
};


//Utility function
ll min(ll a,ll b)
{
    if(a<b)
        return a;
    return b;
}

//Matrix to store the visited cells
vector<vector<bool>> vis;

//Function to check if the given cell is valid or not
bool isValid(int x,int y, int n, int m)
{
    //If cell is out of bounds or visited then return false
    if(x<1 or y<1 or x>n or y>m or vis[x][y])
        return false;

    return true;
}


int main() 
{
    //Input Size of matrix
    int n,m;
    cin>>n>>m;

    ll matrix[n+1][m+1],dist[n+1][m+1],querie_arr[n+m+2];
    
    //Initializing the arrays with large values
    for(int i=0;i<n+m+2;i++)
        querie_arr[i] = (ll)(1e9 +1);
    
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m;j++)
        {
            matrix[i][j] = (ll)(1e9 +1);
            dist[i][j] = (ll)(1e9 +1);
        }
    }
    vis.resize(n+1,vector<bool>(m+1,false));
    
    //Reading the destination points and their costs
    int s;
    cin>>s;
    for(int i=0;i<s;i++)
    {
        int x,y;
        ll c;
        cin>>x>>y>>c;
        matrix[x][y] = c;
    }

    //Input starting points
    // and pushing them into a queue
    Queue q;
    int k;
    cin>>k;
    for(int i=0;i<k;i++)
    {
        cell c;
        cin>>c.x>>c.y;
        vis[c.x][c.y] = true;     //mark the starting point as visited
        q.push(c);
        dist[c.x][c.y] = 0;       //distance of starting point is 0
    }

    //Setting the direction vectors
    int dx[] = {-1,0,1,0};
    int dy[] = {0,-1,0,1};
    
    //Performing BFS on Matrix 
    //and finding the shortest distance 
    //of each node from the start points
    while(!q.empty())
    {
        cell c = q.retFront();
        q.pop();
        int x = c.x, y = c.y;

        for(int i=0;i<4;i++)
        {
            int new_x = x + dx[i];
            int new_y = y + dy[i];
            if(isValid(new_x,new_y, n, m))
            {
                    vis[new_x][new_y] = true;
                    cell new_c;
                    new_c.x = new_x;
                    new_c.y = new_y;
                    q.push(new_c);
                    dist[new_x][new_y] = dist[x][y]+1;
            }
        }
    }
    
    //Finding the minimum cost 
    //and storing in the array for each query
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m;j++)
        {
            if(matrix[i][j] != (ll)(1e9 +1))
                querie_arr[dist[i][j]] = min(querie_arr[dist[i][j]],matrix[i][j]);
        }
    }
    
    //Making the queries array as decreasing with minimum cost
    ll mini = (ll)(1e9 +1);
    for(int i=0;i<n+m+2;i++)
    {
        mini = min(mini,querie_arr[i]);
        querie_arr[i] = mini;
    }
    
    //Taking queries
    int queries;
    cin>>queries;
    while(queries--)
    {
        int tr;
        cin>>tr;
        if(tr >= n+m)   //If the query is out of bounds
        {
            if(querie_arr[n+m-1] != (ll)(1e9 +1))
                cout<<(ll)(querie_arr[n+m-1])<<" ";
            else
                cout<<"-1 ";
        }
        else 
            if(querie_arr[tr] == (ll)(1e9 +1))  
                cout<<"-1 ";
            else
                cout<<(ll)(querie_arr[tr])<<" ";  
    }
    return 0;
}