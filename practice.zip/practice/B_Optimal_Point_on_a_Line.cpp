#include<bits/stdc++.h>
using namespace std;

int main()
{
    cin.tie(0);
    ios_base::sync_with_stdio(0);

    int n;
    cin>>n;
    vector<int> x(n);
    for(int i=0;i<n;i++)
        cin>>x[i];

    sort(x.begin(),x.end());
    int i=0,j=n-1;
    // int left_sum=0,right_sum=0;

    // while(i<j)
    // {
    //     int del_left = x[i+1]-x[i];
    //     int del_right = x[j]-x[j-1];
    //     if(left_sum+del_left <= right_sum+del_right)
    //     {
    //         left_sum += del_left;
    //         // if(i+1<j)
    //             i++;
    //         // else    
    //         //     break;
    //     }
    //     else
    //     {
    //         right_sum += del_right;
    //         // if(j-1>i)
    //             j--;
    //         // else    
    //         //     break;
    //     }
    // }
    int mean = (x[i]+x[j])/2;

    // int mid;
    // while(i<j)
    // {
    //     mid = (i+j)/2;
    //     if(x[mid]<mean)
    //         i = mid+1;
    //     else
    //         j = mid;
    // }
    for(i=0; i<n-1; i++)
    {
        if(x[i+1]>mean)
            break;
    }

    cout<<x[i]<<endl;

    return 0;
}