#include<bits/stdc++.h>
using namespace std;

int main()
{
    char str[101];
    gets(str);
    int i=0;
    vector<int> arr;
    for(int i=0; str[i]!='\0'; i++)
    {
        if(str[i]<='3' && str[i]>='1')
            arr.push_back(str[i]-'0');
    }
    sort(arr.begin(), arr.end());

    int len = arr.size();
    for(int i=0; i<len; i++)
    {
        cout<<arr[i];
        if(i<len-1)
            cout<<'+';
    }
    cout<<'\n';
    return 0;
}