#include<bits/stdc++.h>
#define ll long long
using namespace std;

int main()
{
    ll n;
    cin>>n;

    vector<ll> a(n);
    for(ll i=0;i<n;i++)
        cin>>a[i];

    ll k;
    cin>>k;

    vector<ll> dp;      
    dp.resize(n,(ll)(-(1e12)));     //Initializing with -infinity
    dp[0]=a[0];        

    multiset<ll> m_set;
    m_set.insert(a[0]);     
    for(ll i=1;i<n;i++)     //Tabulation
    {
        dp[i]= a[i] + *m_set.rbegin();      
        if(m_set.size()==k)     
        {
            auto it = m_set.find(dp[i-k]);
            m_set.erase(it);
        }
        m_set.insert(dp[i]);     
    }
    cout<<dp[n-1]<<endl;
    return 0;
}