#include<bits/stdc++.h>
using namespace std;
#define ll long long

ll *makelogArr(ll n)
{
    ll *arr = new ll[n+1];
    arr[0] = -1;
    arr[1] = 0;
    ll count=0;
    ll loga=2;
    for(ll i=2; i<=n; i++)
    {
        if(i%loga==0)
        {
            count++;
            loga *= 2;
        }
        arr[i] = count;
    }
    return arr;
}


ll *makePowof2Arr(ll n)
{
    ll *arr = new ll[n+1];
    arr[0] = 1;
    arr[1] = 1;
    ll pow=1;
    for(ll i=2; i<=n; i++)
    {
        if(pow*2<=i)
            pow = pow*2;
        arr[i] = pow;
    }
    return arr;
}

int main()
{
    ll n;
    cin>>n;
    // ll *arr = makelogArr(n);
    // for(ll i=0; i<=n; i++)
    // {
    //     cout<<i<<" "<<arr[i]<<"\n";
    // }

    ll *arr = makePowof2Arr(n);
    for(ll i=0; i<=n; i++)
    {
        cout<<i<<" "<<arr[i]<<"\n";
    }
    return 0;
}