#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin>>n;
    vector<int> a(n);
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }
    int max_disk=n;
    priority_queue<int> q;
    for(int i=n ; i>=0 ; i--)
    {
        q.push(a[i]);
        while(q.top()==max_disk)
        {
            cout<<q.top()<<" ";
            max_disk--;
            q.pop();
        }
    }

    return 0;
}