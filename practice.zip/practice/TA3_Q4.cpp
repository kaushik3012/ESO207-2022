#include<bits/stdc++.h>
using namespace std;

int EmpSkills[100000], EmpTalent[100000], max_eff=INT_MIN;

void combinationUtil(int skills[], int talents[],
                    int start, int end,
                    int index, int r);
 
// The main function that prints
// all combinations of size r
// in arr[] of size n. This function
// mainly uses combinationUtil()
void printCombination(int n, int r)
{
    // A temporary array to store
    // all combination one by one
    int skills[r];
    int talents[r];
 
    // Print all combination using
    // temporary array 'data[]'
    combinationUtil(skills, talents, 0, n-1, 0, r);
}
 
/* arr[] ---> Input Array
data[] ---> Temporary array to
store current combination
start & end ---> Starting and
Ending indexes in arr[]
index ---> Current index in data[]
r ---> Size of a combination to be printed */
void combinationUtil(int skills[], int talents[],
                    int start, int end,
                    int index, int r)
{
    // Current combination is ready
    // to be printed, print it
    if (index == r)
    {
        int sum=0, mini = INT_MAX;
        cout<<"Tal: ";
        for (int j = 0; j < r; j++)
        {
            cout<<talents[j]<<" ";
        }
        cout<<endl;
        cout<<"Skill: ";
        for (int j = 0; j < r; j++)
        {
            cout << skills[j] << " ";
            sum += skills[j];
            mini = min(mini, talents[j]);
        }
        cout << endl;
        max_eff = max(max_eff, sum*mini);
        cout<<"Eff: "<<sum*mini<<endl;
        return;
    }
 
    // replace index with all possible
    // elements. The condition "end-i+1 >= r-index"
    // makes sure that including one element
    // at index will make a combination with
    // remaining elements at remaining positions
    for (int i = start; i <= end && end - i + 1 >= r - index; i++)
    {
        skills[index] = EmpSkills[i];
        talents[index] = EmpTalent[i];
        combinationUtil(skills, talents, i+1, end, index+1, r);
    }
}
 

int main()
{
    int M,k;
    cin>>M>>k;
    
    srand(time(NULL)*time(NULL));
    for(int i=0;i<M;i++)
    {
        // cin>>EmpSkills[i]>>EmpTalent[i];
        EmpSkills[i] = 10 + rand()%100;
        EmpTalent[i] = 10 + int(rand()%100);
        cout<<EmpSkills[i]<<" "<<EmpTalent[i]<<endl;
    }

    int arr[M];
    for(int i=1; i<=M; i++)
    {
        arr[i] = i;
    }

    printCombination(M, k);

    cout<<'\n'<<max_eff<<endl;

    // vector<int> skillSum, talentMin;
    // int eff=INT_MIN;
    // for(int i=0; i<M-k; i++)
    // {
    //     int mini = EmpTalent[i];
    //     int sum=0;
    //     for(int j=i; j<i+k; j++)
    //     {
    //         mini = min(mini, EmpTalent[j]);
    //         sum += EmpSkills[j];
    //     }
    //     eff = max(eff, sum*mini);
    //     cout<<eff<<" ";
    // }

    // printf("\nEfficiency: %d", eff);
    return 0;

}