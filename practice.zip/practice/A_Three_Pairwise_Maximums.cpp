#include<bits/stdc++.h>
#define ll long long
using namespace std;

int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        ll x,y,z;
        cin>>x>>y>>z;
        if(x==y && y==z && z==x)
        {
            cout<<"YES\n";
            cout<<x<<" "<<y<<" "<<z<<endl;
            continue;
        }
        else if(x!=y && y!=z && z!=x)
        {
            cout<<"NO"<<endl;
            continue;
        }
        else if(x==y)
        {
            if(z<x)
            {
                cout<<"YES\n";
                cout<<1<<" "<<z<<" "<<x<<endl;
                continue;
            }
            else
            {
                cout<<"NO"<<endl;
                continue;
            }
        }
        else if(y==z)
        {
            if(x<y)
            {
                cout<<"YES\n";
                cout<<1<<" "<<x<<" "<<z<<endl;
                continue;
            }
            else
            {
                cout<<"NO"<<endl;
                continue;
            }
        }
        else if(z==x)
        {
            if(y<z)
            {
                cout<<"YES\n";
                cout<<1<<" "<<y<<" "<<x<<endl;
                continue;
            }
            else
            {
                cout<<"NO"<<endl;
                continue;
            }
        }
    }
    return 0;
}