#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n,k;
    cin>>n>>k;
    vector<int> a(n);
    for(int i=0;i<n;i++)
        cin>>a[i];
    sort(a.begin(),a.end());
    int sum=0;
    for(int i=0; i<n && k>0; i++)
    {
        a[i]=a[i]-sum;
        if(a[i]!=0)
        {
            cout<<a[i]<<'\n';
            sum += a[i];
            k--;
        }
    }
    while(k--)
        cout<<'0'<<'\n';
    return 0;
}