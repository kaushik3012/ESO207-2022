#include<bits/stdc++.h>
#define ll long long
using namespace std;

ll func(ll x, ll a)
{
    ll ans = (ll)(x/a) + (ll)(x%a);
    return ans;
}

ll findMax(ll l, ll r, ll a)
{
    ll max = INT_MIN;
    for(ll i=r; i>=l; i--)
    {
        ll ans = func(i, a);
        if(ans>max)
            max=ans;
    }
    return max;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    cin>>t;
    while(t--)
    {
        ll l,r,a;
        cin>>l>>r>>a;

        ll max = findMax(l,r,a);

        cout<<max<<endl;
    }
    return 0;
}