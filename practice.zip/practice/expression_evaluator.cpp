#include<bits/stdc++.h>
using namespace std;

stack<char> oStack;
stack<int> nStack;

int execute(char oper)
{
    int n1, n2;
    n1 = nStack.top();
    nStack.pop();
    n2 = nStack.top();
    nStack.pop();

    if(oper=='+')
        return n1+n2;
    if(oper=='-')
        return n2-n1;
    if(oper=='*')
        return n1*n2;
    if(oper=='/')
        return n2/n1;
    if(oper=='^')
        return pow(n2,n1);
    return -1;
}

int insidePriority(char op)
{
    if(op=='+' || op=='-')
        return 1;
    if(op=='*' || op=='/')
        return 2;
    if(op=='^')
        return 3;
    if(op=='(')
        return 0;
    return -1;
}

int outsidePriority(char op)
{
    if(op=='+' || op=='-')
        return 1;
    if(op=='*' || op=='/')
        return 2;
    if(op=='^')
        return 4;
    if(op=='(')
        return 5;
    return -1;
}



void eval(char *exp)
{
    
    int i=0;
    int l = strlen(exp);
    while(i<l)
    {
        char x = exp[i];
        if(x>='0' && x<='9')
            nStack.push(int(x-'0'));
        else if(x ==')')
        {
            while(oStack.top()!='(')
            {
                nStack.push(execute(oStack.top()));
                oStack.pop();
            }
            oStack.pop();
        }
        else
        {
            while(insidePriority(oStack.top())>=outsidePriority(x))
            {
                execute(oStack.top());
                oStack.pop();
            }
            oStack.push(x);
        }
        i++;
    }
}


int main()
{
    char exp[30];
    gets(exp);

    eval(exp);
    cout<<nStack.top()<<endl;
    return 0;
}