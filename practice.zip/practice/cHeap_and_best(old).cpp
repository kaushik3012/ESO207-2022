// #include<bits/stdc++.h>
#include<iostream>
#include<vector>
#define ll long long
using namespace std;

int main()
{
    unsigned ll q, c;
    vector<unsigned ll> products;
    cin>>q;
    while(q--)
    {
        int a;
        cin>>a;
        switch(a)
        {
            case 1:
                cin>>c;
                if(products.size()==0)
                {
                    products.push_back(c);
                    break;
                }
                else
                {
                    if(c>*(products.end()-1))
                    {
                        products.push_back(c);
                        break;
                    }
                    else
                    {
                        for(unsigned ll i=0; i<products.size(); i++)
                        {
                            if(c<products[i])
                            {
                                products.insert(products.begin()+i, c);
                                break;
                            }
                        }
                    }
                }
                break;
            case 2:
                if(products.size()>0)
                {
                    products.erase(products.end()-1);
                }
                break;
            case 3:
                cout<<(*(products.end()-1)-*(products.begin()))<<endl;
                break;
        }
    }
    return 0;
}
