#include<bits/stdc++.h>
using namespace std;
#define ll long long

bool isLucky(int n)
{
    if(n==0)
        return false;
    
    ll count=0;
    while(n!=0)
    {
        int r = n%10;
        if(r!=4 && r!=7)
            return false;
        n/=10;
    }
    return true;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    ll n;
    cin>>n;
    ll count=0;
    while(n!=0)
    {
        int r = n%10;
        if(r==4 || r==7)
            count++;
        n/=10;
    }

    if(isLucky(count))
        cout<<"YES\n";
    else
        cout<<"NO\n";
    return 0;
}