#include<iostream>
using namespace std;

int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int a,b,c,x,y, flag=0;
        cin>>a>>b>>c>>x>>y;

        if(a<x)
        {
            if(c >= x-a)
            {
                c = c - (x-a);
                a = x;
            }
            else
            {
                flag=1;
            }
        }

        if(b<y)
        {
            if(c >= y-b)
            {
                c = c - (y-b);
                b = y;
            }
            else
            {
                flag=1;
            }
        }

        if(flag==0)
        {
            cout<<"YES"<<endl;
        }
        else
        {
            cout<<"NO"<<endl;
        }
    }

    return 0;
}