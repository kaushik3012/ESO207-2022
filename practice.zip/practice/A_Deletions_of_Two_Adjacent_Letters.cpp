#include<bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    scanf("%d\n",&t);
    while(t--)
    {
        char s[50];
        gets(s);
        char c;
        scanf("%c\n",&c);
        
        int flag=0;
        for(int i=0; s[i]!='\0'; i++)
        {
            if(s[i]==c && i%2==0)
            {
                flag=1;
                break;
            }
        }
        if(flag==1)
            printf("YES\n");
        else
            printf("NO\n");
    }
    return 0;
}