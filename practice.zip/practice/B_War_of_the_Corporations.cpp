#include<bits/stdc++.h>
using namespace std;

int main()
{
    string s1, s2;
    getline(cin, s1);
    getline(cin, s2);
    int n = s1.size();
    int m = s2.size();
    int count=0, ans=0;
    for(int i=0; i<n-m+1; i++)
    {
        int j=i;
        count=0;
        for(; j<i+m; j++)
        {
            if(s1[j]==s2[j-i])
            {
                count++;
            }
            else
            {
                count=0;
                break;
            }
        }

        if(count==m)
        {
            ans++;
            i=i+m-1;
        }
    }
    cout<<ans<<endl;
    return 0;
}