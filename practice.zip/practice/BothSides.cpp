#include<bits/stdc++.h>
using namespace std;


int solve(vector<int> &A, int B) {
    int len = A.size();
    if(B==1) 
        return max(A[len-1], A[0]);
    queue<int> Q;
    int max_sum=INT_MIN, sum=0;
    for(int i=len-B; i<len; i++)
    {
        Q.push(A[i]);
        sum+=A[i];
    }
    for(int i=0; i<B; i++)
    {
        max_sum = max(max_sum, sum);
        sum-=Q.front();
        Q.pop();
        sum+=A[i];
        Q.push(A[i]);
    }
    
    // for(int i=0; i<B+1; i++)
    // {
    //     int sum=0;
    //     int j;
    //     for(j=len-i; j<len; j++)
    //     {
    //         sum+=A[j];
    //         cout<<A[j]<<" ";
    //     }
    //     for(j=0; j<B-i; j++)
    //     {
    //         sum+=A[j];
    //         cout<<A[j]<<" ";
    //     }
    //     cout<<'\n';
    //     if(sum>max)
    //         max=sum;
    // }
    return max_sum;
}

int main()
{
    int n,b;
    cin>>n;
    vector<int> A(n);
    for(int i=0; i<n; i++)
        cin>>A[i];
    cin>>b;
    cout<<solve(A,b)<<endl;
    return 0;
}