#include <bits/stdc++.h>
#define int long long
using namespace std;

class cell{
    public:
    int x,y;
};


int n,m;

int dx[]={-1,0,1,0};
int dy[]={0,-1,0,1};

vector<vector<bool>> vis;

bool isValid(int x,int y){
    if(x<1 or y<1 or x>n or y>m or vis[x][y])
        return false;
    return true;
}

int32_t main() {
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */  
    cin>>n>>m;
    int cost[n+1][m+1],dist[n+1][m+1],mincost[n+m];
    
    for(int i=0;i<n+m;i++)
        mincost[i]=(int)(1e9+1);
    
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++)
            cost[i][j]=(int)(1e9+1),dist[i][j]=0;
    }
    vis.resize(n+1,vector<bool>(m+1,false));
    
    int s;
    cin>>s;
    for(int i=0;i<s;i++){
        int x,y,c;
        cin>>x>>y>>c;
        cost[x][y]=c;
    }
    queue<cell> q;
    int k;
    cin>>k;
    for(int i=0;i<k;i++){
        cell c;
        cin>>c.x>>c.y;
        vis[c.x][c.y]=true;
        q.push(c);
    }
    
    while(!q.empty()){
        cell c=q.front();
        q.pop();
        int x=c.x,y=c.y;
        for(int i=0;i<4;i++){
            int new_x=x+dx[i];
            int new_y=y+dy[i];
            if(isValid(new_x,new_y)){
                    vis[new_x][new_y]=true;
                    cell c1;
                    c1.x=new_x;
                    c1.y=new_y;
                    q.push(c1);
                    dist[new_x][new_y]=dist[x][y]+1;
            }
        }
    }
    
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            //cout<<dist[i][j]<<" ";
            if(cost[i][j]!=(int)(1e9+1)){
                mincost[dist[i][j]]=min(mincost[dist[i][j]],cost[i][j]);
            }
        }
    }
    
    int mini=(int)(1e9+1);
    for(int i=0;i<n+m;i++){
        mini=min(mini,mincost[i]);
        mincost[i]=mini;
    }
    
    int quer;
    cin>>quer;
    while(quer--){
        int tr;
        cin>>tr;
        if(tr<=0)
            cout<<"-1 ";
        else
        {
            if(tr>=n+m)
            {
                if(mincost[n+m-1]!=(int)(1e9+1))
                    cout<<mincost[n+m-1]<<" ";
                else
                    cout<<"-1 ";
            }
            else if(mincost[tr]==(int)(1e9+1))
                cout<<"-1 ";
            else
                cout<<mincost[tr]<<" ";
        }
    }
    return 0;
}