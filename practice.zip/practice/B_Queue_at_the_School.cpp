#include<bits/stdc++.h>
using namespace std;

void swap(char &a,char &b)
{
    char temp = a;
    a = b;
    b = temp;
}

int main()
{
    int n,t;
    scanf("%d %d\n",&n,&t);
    string str;
    getline(cin, str);
    while(t--)
    {
        for(int i=0; i<n-1; i++)
        {
            if(str[i] == 'B' && str[i+1] == 'G')
            {
                swap(str[i],str[i+1]);
                i++;
            }
        }
    }
    cout<<str<<'\n';
    return 0;
}