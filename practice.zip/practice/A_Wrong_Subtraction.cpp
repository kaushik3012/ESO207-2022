#include<bits/stdc++.h>
using namespace std;
#define ll long long

int main()
{
    int k;
    ll n;
    cin>>n>>k;
    ll res=n;
    while(k--)
    {
        if(res%10==0)
            res/=10;
        else
            res--;
    }
    cout<<res<<'\n';
    return 0;
}