#include<bits/stdc++.h>
using namespace std;

bool isVowel(char c)
{
    if(c=='a' || c=='e' || c=='i' || c=='o' || c=='u')
        return true;
    return false;
}

int main()
{
    int n;
    scanf("%d\n",&n);
    vector<string> strArr(n+1);
    for(int i=1; i<=n; i++)
        getline(cin, strArr[i]);

    int arr[n+1];
    arr[0]=0;

    for(int i=1; i<=n; i++)
    {
        if(isVowel(strArr[i][0]) && isVowel(strArr[i][strArr[i].length()-1]))
            arr[i]=arr[i-1]+1;
        else    
            arr[i]=arr[i-1];
    }

    int q;
    scanf("%d\n",&q);
    while(q--)
    {        
        int l,r;
        char c;
        cin>>l>>c>>r;
        cout<<arr[r]-arr[l-1]<<'\n';
    }
    return 0;
}