#include<bits/stdc++.h>
using namespace std;

int main()
{
    vector<int> arr;
    int n;
    cin >> n;
    for(int i=0; i<n; i++)
    {
        int a;
        cin >> a;
        if(a!=0)
            arr.push_back(a);
    }
    sort(arr.begin(), arr.end(), greater<int>());
    int count = 0;

    if(arr.size()!=0)
    {
        count++;
        for(int i=0; i<arr.size()-1; i++)
        {
            if(arr[i]!=arr[i+1])
                count++;
        }
    }
    cout << count<<endl;

    return 0;
}