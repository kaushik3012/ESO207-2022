#include<bits/stdc++.h>
using namespace std;

int countDomino(int m, int n)
{
    if(m<1 || n<1)
        return 0;
    
    if(m==1 && n==1)
        return 0;
    
    if(m>1 && n==1)
        return m/2;
    
    if(n>1 && m==1)
        return n/2;

    return max( ( (m*(n/2)) + ((m/2)*(n%2)) ), ( (n*(m/2)) + ((n/2)*(m%2)) ) );
}


int main()
{
    int M,N;
    cin>>M>>N;
    cout<<countDomino(M,N)<<'\n';
    return 0;
}