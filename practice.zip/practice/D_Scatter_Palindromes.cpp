#include<bits/stdc++.h>
using namespace std;

int scatter_pal(string &s)
{
    map<int, int> x;
    int ans = 0, last = 0, n = s.length();
    x[0] = 1;
    for(int i = 0; i < n; i++)
    {
        int a = s[i] - 'a';
        ans ^= 1 << a;
        for(int i=0; i<26; i++)
            last += x[ans ^ (1 << i)];
        last += x[ans];
        x[ans]++;
    }
    return last;
}

int main()
{
    string s;
    getline(cin,s);
    
    cout<<scatter_pal(s)<<endl;
    return 0;
}