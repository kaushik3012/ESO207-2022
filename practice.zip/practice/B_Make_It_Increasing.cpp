#include<iostream>
#define ll long long
using namespace std;

int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n;
        cin>>n;
        ll a[n];
        for (int i = 0; i < n; i++)
        {
            cin>>a[i];
        }
        int flag=0;
        int count=0;
        for(int i=n-1; i>0;)
        {
            if(a[i]<=0)
            {
                flag=1;
                break;
            }
            if(a[i-1]>=a[i])
            {
                count++;
                a[i-1] = (ll)(a[i-1]/2);
                continue;
            }
            i--;
        }

        if(flag==0)
        {
            for(int i=0; i<n-1; i++)
            {
                if(a[i]>=a[i+1])
                {
                    flag=1;
                    break;
                }
            }
        }

        if(flag==0)
            cout<<count<<endl;
        else
            cout<<"-1"<<endl;
    }
    return 0;
}