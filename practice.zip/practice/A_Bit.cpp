#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin>>n;
    scanf("\n");
    int x=0;
    char str[4];
    while(n--)
    {
        gets(str);
        for(int i=0; i<3; i++)
        {
            if(str[i]=='+')
            {
                x++;
                break;
            }
            else
                if(str[i]=='-')
                {
                    x--;
                    break;
                }
        }
    }
    cout<<x<<'\n';
    return 0;
}