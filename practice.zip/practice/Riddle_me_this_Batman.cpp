#include<iostream>
#include <vector>

using namespace std;

vector<int> adj[100001]; //Adjacency list to store the graph
bool vis[100001];     //Visited array to check if a node is visited or not
int par[100001];    //Parent array to store the parent of a node
vector<bool> isOnCycle(100001,false);   //Array to check if a node is on a cycle or not

int parent[100001],Rank[100001];    //Parent and Rank array to store the parent and rank of a node

//Function to find the parent of a node
int findParent(int node)    
{
    //If the parent of the node is itself then return the node
    if(parent[node] == node)
        return node;
    
    //If the parent of the node is not itself then find the parent of the node
    return parent[node] = findParent(parent[node]);
}

//Function to find the rank of a node
void Union(int a,int b)
{
    a=findParent(a);    //Find the parent of a
    b=findParent(b);    //Find the parent of b

    if(Rank[a]>Rank[b]) //If the rank of a is greater than b then make a as parent of b
        parent[b] = a;
    else 
        if(Rank[a]<Rank[b]) //If the rank of b is greater than a then make b as parent of a
            parent[a] = b;
        else    //If the rank of a and b are equal then make a as parent of b and increment the rank of a
        {
            parent[b]=a;
            Rank[a]++;
        }
}

//Function to perform Depth First Search on the graph
void dfs(int node,int parent)
{
    vis[node]=true;   //Mark the node as visited   
    par[node]=parent;   //Store the parent of the node

    //Go through all the nodes adjacent to the node
    for(auto x:adj[node])
    {
        if(x == parent)   //If the node is the parent of the node then continue
            continue;
        
        //If the node is not visited then perform DFS on the node
        if(!vis[x])
            dfs(x,node);
        else 
            if(!isOnCycle[node])
            {
                int y = node,cycLen = 0;    //y is the node and cycLen is the length of the cycle
                isOnCycle[x] = true;    
                Union(node,x);      //Union the node with the node adjacent to it
                while(y!=x && y!=-1)
                {
                    isOnCycle[y] = true;    //Mark the node as on a cycle
                    cycLen++;   //Increment the length of the cycle

                    //If the node is not the parent of the node then union the node with the node adjacent to it
                    if(par[y]!=-1 && findParent(y)!=findParent(par[y])) 
                        Union(y,par[y]); 
                    y = par[y];     //Go to the parent of the node
                }
            }
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    //Input the number of nodes and edges
    int n,m;
    cin>>n>>m;
    
    for(int i=1;i<=n;i++)
    {
        parent[i]=i;    //Initializing the parent array
        Rank[i]=1;    //Initializing the rank array
    }
    
    //Input the edges
    for(int i=0;i<m;i++)
    {
        int x,y;
        cin>>x>>y;

        //Add the edge to the adjacency list
        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    
    //Performing DFS on the graph
    for(int i=1;i<=n;i++)
    {
        if(!vis[i])
            dfs(i,-1);
    }
    
    vector<int> result(m+n+1, 0); //Array to store the result

    //Go through all the nodes
    for(int i=1;i<=n;i++)
    {
        //If the node is not on a cycle then add 1 to the result
        if(isOnCycle[i])    
            result[findParent(i)]++;
    }
    
    //Print the result
    long long ans=0;
    vector<int> :: iterator p;
    for (p = result.begin(); p != result.end(); p++)
        ans += 1LL*(*p)*((*p)-1);     //Calculating the answer
    
    cout<<(long long)(ans)<<endl;
    return 0;
}