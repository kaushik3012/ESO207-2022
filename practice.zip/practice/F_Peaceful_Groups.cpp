#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin>>n;
    vector<int> a(n);
    int maxVal=0;
    for(int i=0; i<n; i++)
    {
        cin>>a[i];
        maxVal = max(maxVal, a[i]);
    }
    maxVal++;
    vector<int> flags(maxVal, 0);

    

    for(int i=1; i<n-1; i++)  
    {
        if(a[i]!=a[i-1] && a[i]!=a[i+1])
            flags[a[i]]=1;

    }

    // for(int i=1; i<n-1; i++)  
    // {
    //     if(a[i]!=a[0])
    //     {
    //         flags[a[0]] = 1;
    //         break;
    //     }
    // }

    flags[0]=0;
    int sum=0;
    for(int i=0; i<maxVal; i++)
    {
        // cout<<i<<' '<<flags[i]<<endl;
        sum+=flags[i];
    }
    // cout<<endl;
    cout<<sum<<endl;
    return 0;
}