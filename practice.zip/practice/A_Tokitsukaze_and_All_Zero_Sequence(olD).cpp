#include<bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n;
        cin>>n;
        vector<int> a(n);
        for(int i=0; i<n; i++)
        {
            cin>>a[i];
        }
        sort(a.begin(), a.end());
        int i,flag=0;
        for( i=0; i<n; i++)
        {
            if(a[i]==0)
                flag=1;
            else
                break;
        }
        if(flag==1)
        {
            cout<<n-i<<endl;
            continue;
        }

        for(int i=0; i<n; i++)
        {
            if(a[i]==a[i+1])
            {
                flag=2;
                break;
            }
        }
        if(flag==2)
        {
            cout<<n<<endl;
            continue;
        }
        else    
            cout<<n+1<<endl;
    }
    return 0;
}