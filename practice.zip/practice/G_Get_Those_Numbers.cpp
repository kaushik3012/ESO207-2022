#include<bits/stdc++.h>
#define ld long double
#define ll long long
using namespace std;

int main()
{
    cin.tie(0);
    ios_base::sync_with_stdio(0);

    ld t;
    cin>>t;
    while(t--)
    {
        ld n,m;
        cin>>n>>m;
        ld ans = (ld)((m/n)*2) - (ld)((m/n)/n);
        cout<<(ll)(ans)<<endl;
    }
    return 0;
}