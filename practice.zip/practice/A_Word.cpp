#include<bits/stdc++.h>
using namespace std;

void convertToUpper(string &s)
{
    for(int i=0; i<s.size(); i++)
        s[i] = toupper(s[i]);
}

void convertToLower(string &s)
{
    for(int i=0; i<s.size(); i++)
        s[i] = tolower(s[i]);
}

int main()
{
    string str;
    getline(cin, str);
    int len = str.size();

    int lowers=0;
    for(int i=0; i<len; i++)
    {
        if(str[i]>='a' && str[i]<='z')
            lowers++;
    }

    if(lowers<(len+1)/2)
        convertToUpper(str);
    else
        convertToLower(str);

    cout<<str<<'\n';
    return 0;
}