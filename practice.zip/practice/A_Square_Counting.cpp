#include<bits/stdc++.h>
#define ll long long
using namespace std;

int main()
{
    ll t;
    cin>>t;
    
    while(t--)
    {
        ll n,s;
        cin>>n>>s;

        ll sq = n*n;
        ll count = s/sq;
        cout<<count<<'\n';
    }
    return 0;
}