#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin >> n;
    int count=0;
    int prev=0;
    while(n--)
    {
        int p;
        cin >> p;
        
        if(prev!=p)
        {
            count++;
            prev=p;
        }
    }
    cout<<count<<'\n';
    return 0;
}