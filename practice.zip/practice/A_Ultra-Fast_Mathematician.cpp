#include<bits/stdc++.h>
using namespace std;

int main()
{
    char n1[101];
    gets(n1);

    char n2[101];
    gets(n2);

    for(int i=0; n1[i]!='\0'; i++)
    {
        if(n1[i]==n2[i])
            cout<<'0';
        else
            cout<<'1';
    }
    cout<<'\n';
    return 0;
}
