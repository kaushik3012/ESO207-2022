#include<bits/stdc++.h>
using namespace std;

void shift_letter(char &c, char ch)
{
    if(c!='z')
        c++;
    else    
        c='a';
    
    if(c==ch)
        shift_letter(c, ch);
}

int main()
{
    string s;
    getline(cin, s);

    int n = s.length();
    char ch = '0';
    for(int i=0; i<n-1; i++)
    {
        if(s[i]==s[i+1])
        {
            if(i==0)
            {
                shift_letter(s[i], ch);
            }
            else
            {
                if(s[i]!=s[i-1])
                {
                    if(i==n-2)
                        shift_letter(s[i+1], '0');
                    else
                        shift_letter(s[i+1], s[i+2]);
                }
                else
                    shift_letter(s[i],ch);                    
            }
        }
        else
            ch = s[i];
    }
    cout<<s<<endl;
    return 0;
}