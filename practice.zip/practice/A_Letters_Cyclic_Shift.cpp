#include<bits/stdc++.h>
using namespace std;

int main()
{
    string s;
    cin>>s;
    int n = s.length();
    int flag=0,count=0;
    for(int i=0; i<n; i++)
    {
        if(s[i]!='a')
        {
            s[i] = s[i] - 1;
            flag=1;
        }
        else
            if(flag!=0 && s[i]=='a')
                break;
            else
                count++;
    }
    if(count==n)
        s[n-1] = 'z';
    cout<<s<<endl;
    return 0;
}