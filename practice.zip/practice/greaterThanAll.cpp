#include<bits/stdc++.h>
using namespace std;

int solve(vector<int> &A) 
{
    int maxi = A[0];
    int len = A.size(), count=1;
    for(int i=1; i<len; i++)
    {
        if(A[i]>maxi)
        {
            count++;
            maxi = A[i];
        }
    }
    return count;
}

int main()
{
    int n;
    cin>>n;
    vector<int> A(n);
    for(int i=0; i<n; i++)
        cin>>A[i];
    cout<<solve(A)<<endl;
    return 0;
}