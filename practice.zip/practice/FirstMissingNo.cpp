#include<bits/stdc++.h>
using namespace std;

int firstMissingPositive(vector<int> &A) {
    const int size_arr = 1000000;
    int arr[size_arr]={0};
    int len = A.size();
    
    for(int i=0; i<len; i++)
    {
        if(A[i]>0)
        {
            arr[A[i]]=1;
        }
    }
    // for(int i=0; i<len; i++)
    // {
    //     cout<<arr[i]<<" ";
    // }
    cout<<endl;
    for(int i=1; i<size_arr; i++)
    {
        if(arr[i]==0)
            return i;
    }
    return 0;
}


int main()
{
    int n;
    cin>>n;
    vector<int> A(n);
    for(int i=0; i<n; i++)
    {
        cin>>A[i];
    }
    cout<<firstMissingPositive(A)<<endl;
    return 0;
}