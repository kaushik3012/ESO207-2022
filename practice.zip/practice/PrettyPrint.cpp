#include<bits/stdc++.h>
using namespace std;

vector<vector<int> > prettyPrint(int n) {
    vector<vector<int>> result;
    // number of rows and columns to be printed
    int s = 2 * n - 1;
 
    // Upper Half
    for (int i = 0; i < (s / 2) + 1; i++) {
        
        int m = n;
 
        // Decreasing part
        for (int j = 0; j < i; j++) {
            cout << m << " ";
            m--;
        }
 
        // Constant Part
        for (int k = 0; k < s - 2 * i; k++) {
            cout << n - i << " ";
        }
 
        // Increasing part.
        m = n - i + 1;
        for (int l = 0; l < i; l++) {
            cout << m << " ";
            m++;
        }
 
        cout << endl;
    }
 
    // Lower Half
    for (int i = s / 2 - 1; i >= 0; i--) {
 
        // Decreasing Part
        int m = n;
        for (int j = 0; j < i; j++) {
            cout << m << " ";
            m--;
        }
 
        // Constant Part.
        for (int k = 0; k < s - 2 * i; k++) {
            cout << n - i << " ";
        }
 
        // Decreasing Part
        m = n - i + 1;
        for (int l = 0; l < i; l++) {
            cout << m << " ";
            m++;
        }
        cout << endl;
    }
    return result;
}

int main()
{
    int n;
    cin>>n;
    vector<vector<int>> result = prettyPrint(n);
    for(int i = 0; i < result.size(); i++)
    {
        for(int j = 0; j < result[i].size(); j++)
        {
            cout<<result[i][j]<<" ";
        }
        cout<<endl;
    }
    return 0;
}