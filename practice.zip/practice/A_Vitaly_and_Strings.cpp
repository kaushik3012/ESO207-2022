#include<bits/stdc++.h>
using namespace std;

void shift_letter(char &c)
{
    if(c!='z')
        c++;
    else
        c='a';
}

int main()
{
    string s,t;
    getline(cin, s);
    getline(cin, t);

    int n = s.length();
    string new_s=s;
    int flag=0;
    for(int i=n-1; i>=0; i--)
    {
        shift_letter(new_s[i]);
        if(new_s<t && new_s>s)
        {
            flag=1;
            break;
        }
    }

    if(flag==0)
        cout<<"No such string"<<endl;
    else
        cout<<new_s<<endl;
    return 0;
}