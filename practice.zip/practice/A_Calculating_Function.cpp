#include<bits/stdc++.h>
#define ll long long
using namespace std;

ll func(ll n)
{
    ll ans=0;
    if(n%2==0)
        ans = n/2;
    else
        ans = -(n+1)/2;
    return ans;
}

int main()
{
    ll n;
    cin >> n;
    cout<<func(n)<<'\n';
    return 0;
}