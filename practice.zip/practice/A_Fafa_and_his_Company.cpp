#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin>>n;
    int i=1, count=0;
    for(; i<n; i++)
    {
        if(n%i==0)
        {
            count++;
        }
    }
    cout<<count<<endl;
    return 0;
}