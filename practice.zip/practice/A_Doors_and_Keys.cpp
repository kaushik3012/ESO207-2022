#include<bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    scanf("%d\n",&t);
    while(t--)
    {
        int r_key=0,b_key=0, g_key=0, flag=0;
        for(int i=0; i<6; i++)
        {
            char ch;
            ch = getchar();
            if(ch == 'r')
                r_key=1;
            else if(ch == 'b')
                b_key=1;
            else if(ch == 'g')
                g_key=1;
            else if( (ch == 'R' && r_key!=1) || (ch == 'B' && b_key!=1) || (ch == 'G' && g_key!=1) )
                flag=1;
        }
        getchar();
        if(flag==0)
            printf("YES\n");
        else
            printf("NO\n");
    }
    return 0;
}