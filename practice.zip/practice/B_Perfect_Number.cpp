#include <iostream>
using namespace std;
 
// finding Sum
int findSum(int A, int B) {
  return A ^ B;
}
 
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int a,b;
        cin>>a>>b;
        cout<<findSum(a,b)<<endl;
    }
    return 0;
}