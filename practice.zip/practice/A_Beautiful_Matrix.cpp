#include<bits/stdc++.h>
using namespace std;

int calc(int i, int j)
{
    int a = abs(2 - i);
    int b = abs(2 - j);
    return a + b;
}

int main()
{
    int n,i,j,flag=0;
    for(i=0; i<5; i++)
    {
        for(j=0; j<5; j++)
        {
            cin>>n;
            if(n==1)
            {
                flag=1;
                break;
            }
        }
        if(flag==1)
            break;
    }
    cout<<calc(i,j);
    return 0;
}