#include<bits/stdc++.h>
using namespace std;
#define ll long long

int main()
{
    ll x;
    cin>>x;
    ll steps=0, i=0;
    for(;i<x;i+=5)
        steps++;
    if(i==x)
    {
        cout<<steps<<'\n';
        return 0;
    }
    for(; i<x; i+=4)
        steps++;
    if(i==x)
    {
        cout<<steps<<'\n';
        return 0;
    }
    for(; i<x; i+=3)
        steps++;
    if(i==x)
    {
        cout<<steps<<'\n';
        return 0;
    }
    for(; i<x; i+=2)
        steps++;
    if(i==x)
    {
        cout<<steps<<'\n';
        return 0;
    }
    for(; i<x; i+=1)
        steps++;
    if(i==x)
    {
        cout<<steps<<'\n';
        return 0;
    }

    cout<<steps<<'\n';
    return 0;
}