#include<bits/stdc++.h>
using namespace std;

int main() 
{
    int tests;
    cin >> tests;
    int count=0;
    while(tests--) 
    {
        int sum=0;
        for(int i=0; i<3; i++)
        {
            int a;
            cin>>a;
            sum+=a;
        }
        if(sum<2);
        else
            count++;    
    }
    cout<<count<<'\n';
    return 0;
}