#include<bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    scanf("%d\n",&t);
    while(t--)
    {
        int n;
        scanf("%d\n",&n);
        char s[n+1];
        gets(s);

        int count=1, count_f=0;
        for(int i=0; s[i]!='\0'; i++)
        {
            if(s[i]==s[i+1])
                count++;
            else    
            {
                if(count%2!=0)
                {
                    count_f++;
                    count=2;
                }
                else
                    count=1;
            }
        }
        cout<<count_f<<endl;
    }
    return 0;
}