#include <iostream>
#define ll long long
using namespace std;
 
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        ll a,b;
        cin>>a>>b;
        if((a+b)%2!=0)
            cout<<'1'<<endl;
        else
            cout<<'0'<<endl;
    }
    return 0;
}