#include<bits/stdc++.h>

#define ll long long int

using namespace std;

int guess(ll n)
{
    ll i=1;
    ll squar;
    ll countroot = 0;
    ll countlinear = 0;
    while(1)
    {
        squar = i*i;
        // cout<<squar<<endl;
        if(squar==n)
            return 1;
        if(squar>n)
            break;
        i++;
    }
    countroot = i;
    i--;
    squar = i*i;
    while(1)
    {
        // cout<<squar<<endl;
        if(squar==n)
        {
            cout<<"First half count: "<<countroot<<"\nSecond half count: "<<countlinear<<endl;
            return 1;
        }
        countlinear++;
        squar++;
    }
    
    return 0;
}

int main()
{
    int t;
    cin>>t;

    srand(time(0)*time(0));
    while(t--)
    {
        ll n;
        n = (long)(1e9) + rand()%(long)(1e11);
        cout<<n<<endl;

        if(guess(n)==1)
            cout<<"Correct\n\n";
        else
            cout<<"Wrong\n\n"<<endl;
    }

    return 0;
}