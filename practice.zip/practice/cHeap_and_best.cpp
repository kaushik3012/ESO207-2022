#include<iostream>
#define ll long long

using namespace std;

//Utility function to swap values of two variables
void swap(ll &a, ll &b)
{
    ll temp = a;
    a = b;
    b = temp;
    return ;
}

//Class to create Binary Heap data structure
class maxHeap 
{
    ll *heap;
    int n;
    int parent(int i) 
    {
        return (i - 1) / 2;
    }

    int left(int i) 
    {
        return 2 * i + 1;
    }

    int right(int i) 
    {
        return 2 * i + 2;
    }

    void heapify(int i) 
    {
        int l = left(i);
        int r = right(i);
        int largest = i;
        if (l <= n && heap[l] > heap[largest])
            largest = l;
        if (r <= n && heap[r] > heap[largest])
            largest = r;
        if (largest != i) 
        {
            swap(heap[i], heap[largest]);
            heapify(largest);
        }
    }

public:
    maxHeap(int cap) 
    {
        n = 0;
        heap = new ll[cap];
    }

    //Function to insert element into the heap
    void insert(ll x) 
    {
        n++;
        int i = n - 1;
        heap[i] = x;
        while (i > 0 && heap[parent(i)] < heap[i]) 
        {
            swap(heap[i], heap[parent(i)]);
            i = parent(i);
        }
    }

    //Function to return size of heap
    int getSize()
    {
        return n;
    }

    //Function to return maximum element from heap
    ll extractMax() 
    {
        if (n <= 0)
            return -1;
        
        if (n == 1)
        {
            n--;
            return heap[0];
        }
  
        ll max = heap[0];
        heap[0] = heap[n - 1];
        n--;
        heapify(0);
        return max;
    }

    //Function to return maximum element of the heap
    ll getMax() 
    {
        return heap[0];
    }

    //Function to return minimum element in the heap
    ll getMin() 
    {
        ll min = heap[n/2];
        for(int i=1+n/2; i<n; i++)
            if(heap[i]<min)
                min = heap[i];
        return min;
    }

};

int main()
{
    int q;
    cin>>q;

    maxHeap h(q+1);
    while(q--)
    {
        int a;
        cin>>a;
        switch(a)
        {
            case 1: 
                ll c;
                cin>>c;
                h.insert(c);
                break;
            case 2:
                h.extractMax();
                break;
            case 3:
                if(h.getSize()<=0)
                    cout<<-1<<endl;
                else
                    cout<< (ll)( h.getMax() - h.getMin() ) <<endl;
                break;
        }
    }
    return 0;
}