#include<bits/stdc++.h>
using namespace std;

int main()
{
    string s;
    getline(cin, s);
    int n = s.length();

    // if(n<2)
    // {
    //     cout<<"NO"<<endl;
    //     return 0;
    // }
    // if(n==2)
    // {
    //     if(s=="AB"||s=="BA")
    //     {
    //         cout<<"YES"<<endl;
    //         return 0;
    //     }
    //     else
    //     {
    //         cout<<"NO"<<endl;
    //         return 0;
    //     }
    // }
    
    // vector<int> v(n);
    // for(int i=0; i<n; i++)
    //     v[i]=0; 

    // for(int i=0; i<n-1; i++)
    // {
    //     if((s[i]=='B' && s[i+1]=='A') || (s[i]=='A' && s[i+1]=='B'))
    //         v[i]=1;
    // }

    // int count=0;
    // for(int i=0; i<n-1; i++)
    // {
    //     if((i==0 || v[i-1]==0) && v[i]==1 && v[i+1]==0)
    //         count++;
    // }

    // if(count>0) 
    //     cout<<"YES"<<endl;
    // else
    //     cout<<"NO"<<endl;
    // return 0;

    int x1=s.find("AB");    // FIRST OCCURENCE OF AB IS X1
    int x2=s.find("BA",x1+2);   // OCCURENCE of BA FROM X1+2 POSITION
    int y1=s.find("BA");
    int y2=s.find("AB",y1+2);
    if((x1!=-1 && x2!=-1)  || (y1!=-1 && y2!=-1))
        cout<<"YES"<<endl;
    else
        cout<<"NO"<<endl;
    return 0;
}