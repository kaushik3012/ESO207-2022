#include<bits/stdc++.h>
using namespace std;

int main()
{
    string s;
    cin>>s;
    int n=s.size();
    if(n%2!=0)
    {
        cout<<"-1"<<endl;
        return 0;
    }

    int no_L=0, no_R=0, no_U=0, no_D=0;
    for(int i=0; i<n; i++)
    {
        if(s[i]=='L')
        {
            no_L++;
        }
        else
            if(s[i]=='R')
            {
                no_R++;
            }
            else
                if(s[i]=='U')
                {
                    no_U++;
                }
                else
                    if(s[i]=='D')
                    {
                        no_D++;
                    }
    }

    int rem=0;
    rem=min(no_D, no_U);
    no_D-=rem;
    no_U-=rem;
    int no_V = no_U+no_D;

    rem=min(no_L, no_R);
    no_L-=rem;
    no_R-=rem;
    int no_H = no_L+no_R;

    int steps = min(no_V, no_H);
    int diff = abs(no_V-no_H);
    steps += diff/2;

    cout<<steps<<endl;
    return 0;
}