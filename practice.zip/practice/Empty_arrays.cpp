#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin>>n;
    queue<int> a;
    for(int i=0;i<n;i++)
    {
        int x;
        cin>>x;
        a.push(x);
    }
    queue<int> b;
    for(int i=0;i<n;i++)
    {
        int x;
        cin>>x;
        b.push(x);
    }

    int c=0;

    while(!a.empty() && !b.empty())
    {
        if(a.front()==b.front())
        {
            a.pop();
            b.pop();
        }
        else
        {
            int front=a.front();
            a.pop();
            a.push(front);
        }
        c++;
    }
    cout<<c<<endl;
    return 0;
}