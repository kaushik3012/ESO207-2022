#include<bits/stdc++.h>
using namespace std;
#define ll long long

int main()
{
    int k,w;
    ll n;
    cin>>k>>n>>w;

    ll sum=0;
    for(int i=1; i<=w; i++)
        sum+=i;
    ll ans=((k*sum) - n); 
    if(ans <=0)
        cout<<0<<'\n';
    else    
        cout<<ans <<'\n';
    return 0;
}