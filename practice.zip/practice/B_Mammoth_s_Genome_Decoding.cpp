#include<bits/stdc++.h>
using namespace std;

int main(){
    int n;
    scanf("%d\n", &n);
    string s;
    cin>>s;

    if(n%4!=0){
        cout<<"==="<<endl;
        return 0;
    }

    int no_A=0, no_C=0, no_G=0, no_T=0, no_ques=0;

    for(int i=0; i<n; i++){
        if(s[i]=='A'){
            no_A++;
        }
        else if(s[i]=='C'){
            no_C++;
        }
        else if(s[i]=='G'){
            no_G++;
        }
        else if(s[i]=='T'){
            no_T++;
        }
        else{
            no_ques++;
        }
    }

    for(int i=0; i<n; i++)
    {
        int min_no=min(no_A, min(no_C, min(no_G, no_T)));

        if(s[i]=='?'){
            if(min_no==no_A){
                s[i]='A';
                no_A++;
            }
            else if(min_no==no_C){
                s[i]='C';
                no_C++;
            }
            else if(min_no==no_G){
                s[i]='G';
                no_G++;
            }
            else if(min_no==no_T){
                s[i]='T';
                no_T++;
            }
            no_ques--;
        }
    }

    if(no_A==no_C && no_C==no_G && no_G==no_A && no_T==no_A && no_ques==0 && no_C==no_T && no_G==no_T){
        cout<<s<<endl;
    }
    else{
        cout<<"==="<<endl;
    }

    return 0;
}