#include<bits/stdc++.h>
using namespace std;

int main()
{
    cin.tie(0);
    ios_base::sync_with_stdio(0);

    int n;
    cin>>n;
    vector<int> a(n);
    for(int i=0;i<n;i++)
        cin>>a[i];
    sort(a.begin(),a.end());
    int max_count=1;
    int count=1;
    int j=1, i=0;

    while(i<n && j<n)
    {
        if(a[j] - a[i] >5)
        {
            i++;
            if(i==j && j==n-1) break;
            else
            if(i==j)
                j++;
            else
                count--;
        }
        else
        {
            j++;
            count++;
        }
        max_count = max(max_count,count);
    }
    cout<<max_count<<endl;
    return 0;
}