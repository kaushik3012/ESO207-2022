#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin >> n;
    int flag=0;
    while(n--)
    {
        int p;
        cin >> p;

        if(p==1)
        {
            cout<<"HARD"<<'\n';
            flag=1;
            break;
        }
    }
    if(flag==0)
        cout<<"EASY"<<'\n';
    return 0;
}