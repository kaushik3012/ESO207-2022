#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n,m;
    cin>>n>>m;
    
    int x,y,a;
    set<int> sx,sy;
    for(int i=1;i<=n;i++)
        sx.insert(i);
    
    for(int i=1;i<=m;i++)
        sy.insert(i);
    
    cin>>x;
    for(int i=0;i<x;i++)
    {
        cin>>a;
        sx.erase(a);
    }
    cin>>y;
    for(int i=0;i<y;i++)
    {
        cin>>a;
        sy.erase(a);
    }

    vector<int> vx,vy;
    for(auto x:sx)
        vx.push_back(x);

    for(auto y:sy)
        vy.push_back(y);

    int max1=0,max2=0;
    for(int i=0;i<vx.size()-1;i++)
        max1=max(max1,vx[i+1]-vx[i]);

    for(int i=0;i<vy.size()-1;i++)
        max2=max(max2,vy[i+1]-vy[i]);

    cout<<max1*max2<<'\n';
    return 0;
}