#include<bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n;
        cin>>n;
        int arr[n];
        for(int i=0; i<n; i++)
            cin>>arr[i];
        if(n<=2)
        {
            cout<<"0"<<endl;
            continue;
        }
        int i=0;
        while(arr[i]==1)
            i++;
        i--;
        int j=n-1;
        while(arr[j]==1)
            j--;
        j++;
        if(j<=i)
        {
            cout<<"0"<<endl;
            continue;
        }
        cout<<j-i<<endl;
    }
    return 0;
}