#include<bits/stdc++.h>
using namespace std;

int main()
{
    char str[101];
    gets(str);

    int count=0,flag=0;
    for(int i=0; str[i]!='\0'; i++)
    {
        for(int j=i+1; str[j]!='\0'; j++)
        {
            if(str[i]==str[j])
            {
                flag=1;
                break;
            }
        }
        if(flag==1)
        {
            flag=0;
            continue;
        }
        count++;
    }
    if(count%2==0)
        cout<<"CHAT WITH HER!";
    else
        cout<<"IGNORE HIM!";
    return 0;
}