#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin>>n;
    int max_capacity = 0;
    int cur_capacity = 0;
    while(n--)
    {
        int a,b;
        cin>>a>>b;
        cur_capacity  = cur_capacity + b - a;
        max_capacity = max(max_capacity,cur_capacity);
    }
    cout<<max_capacity<<'\n';
    return 0;
}