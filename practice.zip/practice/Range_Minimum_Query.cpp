#include<bits/stdc++.h>
using namespace std;
#define ll long long


ll *makePowof2Arr(ll n)
{
    ll *arr = new ll[n+1];
    arr[0] = 1;
    arr[1] = 1;
    ll pow=1;
    for(ll i=2; i<=n; i++)
    {
        if(pow*2<=i)
            pow = pow*2;
        arr[i] = pow;
    }
    return arr;
}

ll *makelogArr(ll n)
{
    ll *arr = new ll[n+1];
    arr[0] = -1;
    arr[1] = 0;
    ll count=0;
    ll loga=2;
    for(ll i=2; i<=n; i++)
    {
        if(i%loga==0)
        {
            count++;
            loga *= 2;
        }
        arr[i] = count;
    }
    return arr;
}

// ll RMQ(ll arr[], ll n, ll i, ll j)
// {
//     if(i==j)
//         return arr[i];
//     ll mid=(i+j)/2;
//     ll left=RMQ(arr,n,i,mid);
//     ll right=RMQ(arr,n,mid+1,j);
//     return min(left,right);
// }

ll B[100000][17];
ll *powarr, *logarr;
void initBarr(ll arr[], ll n)
{
    logarr = makelogArr(n);
    powarr = makePowof2Arr(n);
    ll t1, t2;
    ll k = logarr[n-1];
    for(ll x=0; x<n; x++)
    {
        t1 = min(arr[x], arr[x+1]);
        t2 = min(t1, arr[x+2]);
        for(ll y=0; y<k; y++)
        {
            B[x][y] = min(t1,t2);
            t1 = B[x][y];
            t2 = arr[x+powarr[y]];
            // cout<<B[x][y]<<" ";
        }
        // cout<<"\n";
    }
}


ll rangeMinima(ll A[], ll n, ll i, ll j)
{
    ll L=j-i;
    ll t = powarr[L-1];
    ll k = logarr[L-1];
    
    if(t==L)
        return B[i][k];
    else
        return min(B[i][k],B[j-t+1][k]);
}

int main()
{
    ll n,q;
    cin>>n>>q;
    ll a[n];
    for(ll i=0; i<n;i++)
        cin>>a[i];
    initBarr(a,n);

    while(q--)
    {
        ll l,r;
        char ch;
        cin>>ch>>l>>r;
        if(ch=='q')
        {
            // cout<<RMQ(a,n,l-1,r-1)<<endl;
            cout<<rangeMinima(a,n,l-1,r-1)<<endl;
            
        }
        else
            a[l]=r;
    }
    
    return 0;
}