#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin>>n;
    double ans=0;
    for(int i=0; i<n; i++)
    {
        double a;
        cin>>a;
        ans += (double)(a/100) ;
    }
    cout<<fixed<<setprecision(12)<<(100*ans/n)<<endl;
    return 0;
}