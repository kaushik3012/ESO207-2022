#include<bits/stdc++.h>
using namespace std;
  
void convertLower(char *s)
{
    for(int i=0; s[i]!='\0'; i++)
    {
        if(s[i]>='A' && s[i]<='Z')
            s[i] = s[i] - 'A' + 'a';
    }
}

int main()
{
    char s1[101], s2[101];
    gets(s1);
    gets(s2);

    convertLower(s1);
    convertLower(s2);
    if(strcmp(s1,s2)>0)
        cout<<"1\n";
    else if(strcmp(s1,s2)==0)
        cout<<"0\n";
    else if(strcmp(s1,s2)<0)
        cout<<"-1\n";

    return 0;
}