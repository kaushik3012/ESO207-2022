#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    scanf("%d\n", &n);

    char str[n+1];
    gets(str);

    int count=0;
    for(int i=0; i<n-1; i++)
    {
        if(str[i]==str[i+1])
            count++;
    }
    cout<<count<<'\n';
    return 0;
}