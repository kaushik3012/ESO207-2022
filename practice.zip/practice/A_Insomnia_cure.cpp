#include<bits/stdc++.h>
using namespace std;

int main()
{
    int k,l,m,n,d;
    cin>>k>>l>>m>>n>>d;
    if(k>d && l>d && m>d && n>d)
    {
        cout<<0<<endl;
        return 0;
    }

    int res[d];
    for(int i=0;i<d;i++)
        res[i]=0;
    for(int i=k-1; i<d; i+=k)
        res[i]=1;
    for(int i=l-1; i<d; i+=l)
        res[i]=1;
    for(int i=m-1; i<d; i+=m)
        res[i]=1;
    for(int i=n-1; i<d; i+=n)
        res[i]=1;
    
    int count=0;
    for(int i=0; i<d; i++)
        count+=res[i];
    
    cout<<count<<endl;
    return 0;
}