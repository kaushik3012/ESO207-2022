#include<bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    scanf("%d\n",&t);
    while (t--)
    {
        const int n = 1+ (2e5);
        char a[n];
        gets(a);
        
        int i,count=0;
        for(i=0; a[i]!='\0'; i++)
        {
            if(a[i]=='0')
            {
                count++;
                break;
            }
        }

        while(i>0 && a[i]!='1')
        {
            i--;
            count++;
        }

        cout << count << endl;
    }
}