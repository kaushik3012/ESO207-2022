#include<bits/stdc++.h>
using namespace std;

int main()
{
    int a,b;
    cin>>a>>b;
    int i=0;
    while(1)
    {
        if(a>b)
            break;
        else
        {
            a = 3*a;
            b = 2*b;
            i++;
        }
    }
    cout<<i<<'\n';
    return 0;
}